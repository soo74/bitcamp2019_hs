package com.teamrun.runbike.record.dao;

import com.teamrun.runbike.record.domain.Record;

public interface RecordDao {

	public int insertRecord(Record record);

	
}
