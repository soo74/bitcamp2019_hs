package com.teamrun.runbike.user.service;

public interface UserService {

}
