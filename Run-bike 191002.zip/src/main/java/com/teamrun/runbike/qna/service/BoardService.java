package com.teamrun.runbike.qna.service;


public interface BoardService {

}
